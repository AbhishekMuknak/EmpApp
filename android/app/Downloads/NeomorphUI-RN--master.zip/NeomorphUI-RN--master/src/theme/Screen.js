import {create} from 'react-native-pixel-perfect';
const designResolution={
    width:390,
    height:844
}
export default perfectSize=create(designResolution);