export default Images ={
    AlarmClock: require('../assets/images/alarm-clock.png'),
    Bell:require('../assets/images/bell.png'),
    Bluetooth:require('../assets/images/bluetooth.png'),
    Comment:require('../assets/images/comment.png'),
    Email:require('../assets/images/email.png'),
    Fastbackward:require('../assets/images/fast-backward.png'),
    Fastforward:require('../assets/images/fast-forward.png'),
    Menu:require('../assets/images/menu.png'),
    Notification:require('../assets/images/notification.png'),
    Rain:require('../assets/images/rain.png'),
    Pause:require('../assets/images/pause.png'),
    PhoneCall:require('../assets/images/phone-call.png'),
    Settings:require('../assets/images/settings.png'),
    SpeakerFilledAudioTool:require('../assets/images/speaker-filled-audio-tool.png'),
    Wifi:require('../assets/images/wifi.png'),



}