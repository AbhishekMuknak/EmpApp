export default colors ={
    backgroundColor:'#ecf0f2',
    headerTextColor:'#9ca0a9',
    blueDotColor:'#3f87df',
    redDotColor:'#e8634f',
    yellowDotColor:'#ffc815',
    greenDotColor:'#5b9b6d',
    blackColor:'#000000',
}