import React from 'react';
import Dashboard from './src/Dashboard';

export default function App(){
  return(
    <Dashboard/>
  )
}