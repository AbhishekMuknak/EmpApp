const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const reservationSchema = new Schema({
  vendor_user_id: {
    type: String
  },
  user_id: {
    type: String
  },
  Status: {
    type: String
  },
  name: {
    type: String
  },
  phone_number: {
    type: String
  },
  adults: {
    type: Number
  },
  kids: {
    type: Number
  },
  handicap: {
    type: Number
  },
  highchair: {
    type: Number
  },
  Date: {
    type: String
  },
  time: {
    type: String
  },
  seating_preference: {
    type: Array
  },
  reasons_for_Cancel: {
    type: Array
  },
  Enter_reasons: {
    type: String
  },
  special_occassion: {
    type: String
  },
  dinner_status: {
    type: String
  },
  entry_point: {
    type: String
  },
  reservation_status: {
    type: String
  },
  ETA: {
    type: String
  },
  Request_Date: {
    type: Date
  },
  Seating_Date: {
    type: Date
  },
  dinner_status: {
    type: String
  },
  order_type: {
    type: String
  },
  restaurant_name: {
    type: String
  },
  register_date: {
    type: Date
  }
});
module.exports = mongoose.model("Reservation", reservationSchema);
