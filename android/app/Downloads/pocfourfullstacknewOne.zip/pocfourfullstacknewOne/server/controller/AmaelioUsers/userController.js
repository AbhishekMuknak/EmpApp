const AmaelioUsers = require("../../models/AmaelioUser.model");
const CompleteProfile = require("../../models/Profile.model");
const AboutYourSelf = require("../../models/YourSelf.model");
const loginvalidator = require("./validator/loginvalidator");
const userSignupValidator = require("./validator/signupvalidator");
const sendOtpValidator = require("./validator/sendotpvalidator");
const jwt = require("jsonwebtoken");
const keys = require("../../../config/keys").secretIOkey;
const axios = require("axios");
const sgmail = require("@sendgrid/mail");
sgmail.setApiKey(
  "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"
);

const accountSid = "ACa7e8734f7243eb4e8b322481d1a4376a";
const authToken = "9f375582bf6960e4ec9e6c6ef5e8eeba";
const client = require("twilio")(accountSid, authToken);

exports.user_signup = async (req, res, next) => {
  try {
    const body = req.body;
    const { errors, isValid } = await userSignupValidator(body);
    if (!isValid) {
      return res.status(400).json(errors);
    } else {
      let newUser = new AmaelioUsers({
        email: body.email,
        first_name: body.first_name,
        last_name: body.last_name,
        country_code: body.country_code,
        mobile_number: body.mobile_number,
        password: body.password,
        register_date: Date.now()
      });
      let newUserCreated = await newUser.save();
      if (newUserCreated) {
        const msg = {
          to: newUserCreated.email,
          from: "support@amealio.com",
          subject: "Welcome aboard!",
          text:
            "Welcome aboard! We at Amealio are thrilled to have you. You've successfully signed up and created your Amealio account. Now, here's what you can do with Amealio: - Wait Lift: That's right! Lift the waiting time at restaurants. Just waitlist or check-in on Amealio.- Quick Pick: Skip the queue to get your order. Order on Amealio & pick up when you or your order is ready! Use coupon code 'PICKUPFIRST' for 10% discount on your first food order.- Reservation: Dinner dates or business brekkies, reserve a table on the app for now or later.- Refer your friends & win great discounts on your order.Look out for the QR code at restaurants. Scan it to view menu, order, waitlist or reserve on Amealio.At Amealio, we are always finding ways to improve your dining experience, so stay tuned for newer features. Got something to say about Amealio? We'd love to hear from you!  Write to us at support@Amealio.inNeed help to use Amealio? We are right here.Dine Differently"
        };
        const send = sgmail.send(msg);
        client.messages
          .create({
            body:
              "Welcome aboard! Your Amealio account has been successfully created. Thanks for signing up. We hope you love the app.",
            messagingServiceSid: "MG47e9a75679be5a94cf3c00e9fa1837dd",
            form: "+14152003837",
            to: newUserCreated.mobile_number
          })
          .then(message => res.json(message.sid));
        const otpNumber = Math.floor(100000 + Math.random() * 900000);
        const message = `Please use this OTP: ${otpNumber} to access your account.`;
        const msg1 = {
          to: newUserCreated.email,
          from: "support@amealio.com",
          subject: "OTP",
          text: message
        };
        const send1 = sgmail.send(msg1);
        // if (send) {
        //   res.status(200).json({
        //     message: "Email Send Successfully"
        //   });
        // }
        const form = req.body;
        let newProfile = new CompleteProfile({
          user_id: newUserCreated._id,
          are_you_over_21: form.are_you_over_21 ? form.are_you_over_21 : false,
          when_is_your_birthday_day: form.when_is_your_birthday_day
            ? form.when_is_your_birthday_day
            : "",
          when_is_your_birthday_month: form.when_is_your_birthday_month
            ? form.when_is_your_birthday_month
            : "",
          when_is_your_anniversary_day: form.when_is_your_anniversary_day
            ? form.when_is_your_anniversary_day
            : "",
          when_is_your_anniversary_month: form.when_is_your_anniversary_month
            ? form.when_is_your_anniversary_month
            : "",
          occasion: form.occasion ? form.occasion : [],
          gender: form.gender ? form.gender : "",
          profile_photo: form.profile_photo ? form.profile_photo : []
        });
        let saveProfile = await newProfile.save();
        const body = req.body;
        let newYourself = new AboutYourSelf({
          user_id: newUserCreated._id,
          do_you_have_allergies: body.do_you_have_allergies
            ? body.do_you_have_allergies
            : [],
          dietary_preferences: body.dietary_preferences
            ? body.dietary_preferences
            : "",
          day_you_eat_out: body.day_you_eat_out ? body.day_you_eat_out : "",
          selected_cuisine: body.selected_cuisine ? body.selected_cuisine : "",
          favourite_places: body.favourite_places ? body.favourite_places : "",
          selected_chain: body.selected_chain ? body.selected_chain : "",
          push_notification: body.push_notification
            ? body.push_notification
            : "",
          sms_notification: body.sms_notification ? body.sms_notification : "",
          email_notification: body.email_notification
            ? body.email_notification
            : ""
        });
        let newyourSelf = await newYourself.save();
        next();
      }
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.send_otp = async (req, res, next) => {
  try {
    const body = req.body;
    let user = await AmaelioUsers.findOne({
      mobile_number: body.mobile_number
    });
    const { errors, isValid } = await sendOtpValidator(body);
    if (!isValid) {
      return res.status(400).json(errors);
    } else {
      const otpNumber = Math.floor(100000 + Math.random() * 900000);
      const message = encodeURIComponent(
        `Please use this OTP: ${otpNumber} to access your account.`
      );
      const msg = {
        to: user.email,
        from: 'support@amealio.com' ,
        subject:
          "OTP",
        text:"Please use this OTP: "+ otpNumber + " to access your account"
      };
      sgmail.send(msg);
      try {
        let sentOtp = await axios.get(
          `https://enterprise.smsgupshup.com/GatewayAPI/rest?method=SendMessage&send_to=${body.mobile_number}&msg=${message}&msg_type=TEXT&userid=2000177667&auth_scheme=plain&password=2019AABBcc!&v=1.1&format=text`
        );
        if (sentOtp) {
          //console.log(sentOtp);
          let updateOtpOnDatabase = await AmaelioUsers.findOneAndUpdate(
            {
              mobile_number: body.mobile_number
            },
            {
              $set: {
                OTP: otpNumber
              }
            }
          );
          if (updateOtpOnDatabase) {
            return res.status(200).json({
              message: "OTP sent Successfully"
            });
          }
          //next();
        }
      } catch (err) {
        console.log(err);
      }
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.verify_otp = async (req, res, next) => {
  try {
    const body = req.body;
    let user = await AmaelioUsers.findOne({
      mobile_number: body.mobile_number,
      OTP: body.OTP
    });
    if (user) {
      let change_userStae = await AmaelioUsers.findOneAndUpdate(
        {
          mobile_number: body.mobile_number
        },
        {
          $set: {
            user_verified: true,
            OTP: "sdasd@@#$#"
          }
        }
      );
      if (change_userStae) {
        return res.status(200).json({
          message: "User Verfied Successfully!!"
        });
      }
    } else {
      return res.status(400).json({
        message: "Unable to verify OTP"
      });
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.update_mobile_number = async (req, res, next) => {
  try {
    const body = req.body;
    let update_number = await AmaelioUsers.findOneAndUpdate(
      {
        mobile_number: body.mobile_number
      },
      {
        $set: {
          mobile_number: body.newmobile_number
        }
      }
    );
    if (update_number) {
      req.body.mobile_number = body.newmobile_number;
      next();
    } else {
      res.status(400).json({
        message: "Mobile Number Not Successfully Updated..!"
      });
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.check_unique_mobile_number = async (req, res, next) => {
  try {
    const body = req.body;
    let check_unique_mobile_number = await AmaelioUsers.findOne({
      mobile_number: body.mobile_number
    });
    if (check_unique_mobile_number) {
      return res.status(400).json({
        mobile_number: "Mobile Number already exists"
      });
    }
    next();
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.verify_forgot_password = async (req, res, next) => {
  try {
    const body = req.body;
    const user = new AmaelioUsers();
    const hashed = await user.change_password(body.password);
    let verify_user = await AmaelioUsers.findOneAndUpdate(
      {
        mobile_number: body.mobile_number
      },
      {
        $set: {
          password: hashed
        }
      }
    );
    if (verify_user) {
      return res.status(200).json({
        message: "User successfully verified"
      });
      //}
    } else {
      return res.status(400).json({
        message: "Unable to verify OTP"
      });
    }
    // })
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.user_login = async (req, res, next) => {
  try {
    const body = req.body;
    const mobile_number = body.mobile_number;
    const password = body.password;
    const { errors, isValid } = await loginvalidator(body);
    if (!isValid) {
      return res.status(400).json(errors);
    } else {
      const user = await AmaelioUsers.findOne({
        mobile_number: mobile_number
      });
      if (user && user.user_verified === true) {
        user.comparePassword(password, (err, isMatch) => {
          if (isMatch) {
            // Payload
            const payload = {
              _id: user._id,
              first_name: user.first_name,
              last_name: user.last_name,
              email: user.email,
              mobile_number: user.mobile_number,
              have_submited_details: user.have_submited_details,
              has_admin_approved: user.has_admin_approved
            };
            jwt.sign(payload, keys, (err, token) => {
              res.json({
                success: true,
                token: "Bearer " + token
              });
            });
          } else {
            return res.status(400).json({
              mobile_number: "Invalid Credentials"
            });
          }
        });
      } else {
        return res.status(400).json({
          mobile_number: "Invalid Credentials"
        });
      }
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.get_all_user = async (req, res, next) => {
  try {
    let UserData = await AmaelioUsers.find();
    if (UserData) {
      return res.status(200).json(UserData);
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.user_has_completed_flow = async (req, res, next) => {
  try {
    const id = jwt.verify(req.headers.authorization.split(" ")[1], keys)._id;
    let data = await AmaelioUsers.findOneAndUpdate(
      {
        _id: id
      },
      {
        $set: {
          have_submited_details: true
        }
      }
    );
    return res.status(200).json(data);
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.get_each_user_info = async (req, res, next) => {
  let array = [];
  try {
    const id = jwt.verify(req.headers.authorization.split(" ")[1], keys)._id;
    let UserData = await AmaelioUsers.find({
      _id: id
    });
    let CompleteProfile1 = await CompleteProfile.find({
      user_id: id
    });
    for (let i = 0; i < UserData.length; i++) {
      for (let j = 0; j < CompleteProfile.length; j++) {
        if (i == j) {
          array[i] = MergeRecursive(UserData[i], CompleteProfile1[j]);
        }
      }
    }
    if (array) {
      return res.status(200).json(array);
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

function MergeRecursive(obj1, obj2) {
  for (var p in obj2) {
    try {
      if (obj2[p].constructor == Object) {
        obj1[p] = MergeRecursive(obj1[p], obj2[p]);
      } else {
        obj1[p] = obj2[p];
      }
    } catch (e) {
      obj1[p] = obj2[p];
    }
  }
  return obj1;
}

/************************************************
 * Social Media Login Code
 * *********************************************/

exports.google_user_signup = async (req, res, next) => {
  try {
    const body = req.body;
    let check_unique_email = await AmaelioUsers.findOne({
      email: body.email,
      mobile_number: body.mobile_number
    });
    if (check_unique_email) {
      return res.status(200).json({
        message: "Please Enter Mobile Number"
      });
    }
    const user = await AmaelioUsers.findOne({
      email: body.email
    });
    if (user) {
      if (user && user.user_verified === true) {
        // Payload
        const payload = {
          _id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile_number: user.mobile_number,
          have_submited_details: user.have_submited_details,
          has_admin_approved: user.has_admin_approved
        };
        jwt.sign(
          payload,
          keys,
          {
            expiresIn: 3600
          },
          (err, token) => {
            res.json({
              success: true,
              token: "Bearer " + token
            });
          }
        );
      } else {
        return res.status(400).json({
          mobile_number: "Invalid Credentials"
        });
      }
    } else {
      let newUser = new AmaelioUsers({
        email: body.email ? body.email : "",
        first_name: body.first_name ? body.first_name : "",
        last_name: body.last_name ? body.last_name : "",
        country_code: body.country_code ? body.country_code : "",
        mobile_number: body.mobile_number ? body.mobile_number : "",
        password: body.password ? body.password : "",
        googleid: body.googleid ? body.googleid : "",
        profile_pic_google: body.profile_pic_google
          ? body.profile_pic_google
          : "",
        facebookid: body.facebookid ? body.facebookid : "",
        profile_pic_facebook: body.profile_pic_facebook
          ? body.profile_pic_facebook
          : ""
      });
      let newUserCreated = await newUser.save();
      if (newUserCreated) {
        const msg = {
          to: newUserCreated.email,
          from: "support@amealio.com",
          subject: "Welcome aboard!",
          text:
            "Welcome aboard! We at Amealio are thrilled to have you. You've successfully signed up and created your Amealio account. Now, here's what you can do with Amealio: - Wait Lift: That's right! Lift the waiting time at restaurants. Just waitlist or check-in on Amealio.- Quick Pick: Skip the queue to get your order. Order on Amealio & pick up when you or your order is ready! Use coupon code 'PICKUPFIRST' for 10% discount on your first food order.- Reservation: Dinner dates or business brekkies, reserve a table on the app for now or later.- Refer your friends & win great discounts on your order.Look out for the QR code at restaurants. Scan it to view menu, order, waitlist or reserve on Amealio.At Amealio, we are always finding ways to improve your dining experience, so stay tuned for newer features. Got something to say about Amealio? We'd love to hear from you!  Write to us at support@Amealio.inNeed help to use Amealio? We are right here.Dine Differently"
        };
        const send = sgmail.send(msg);
        if (newUserCreated.mobile_number === "") {
          res.status(201).json({
            message: "Please Enter Mobile Number"
          });
        }
        const form = req.body;
        let newProfile = new CompleteProfile({
          user_id: newUserCreated._id,
          are_you_over_21: form.are_you_over_21 ? form.are_you_over_21 : false,
          when_is_your_birthday_day: form.when_is_your_birthday_day
            ? form.when_is_your_birthday_day
            : "",
          when_is_your_birthday_month: form.when_is_your_birthday_month
            ? form.when_is_your_birthday_month
            : "",
          when_is_your_anniversary_day: form.when_is_your_anniversary_day
            ? form.when_is_your_anniversary_day
            : "",
          when_is_your_anniversary_month: form.when_is_your_anniversary_month
            ? form.when_is_your_anniversary_month
            : "",
          occasion: form.occasion ? form.occasion : [],
          gender: form.gender ? form.gender : "",
          profile_photo: form.profile_photo ? form.profile_photo : []
        });
        let saveProfile = await newProfile.save();
        const body = req.body;
        let newYourself = new AboutYourSelf({
          user_id: newUserCreated._id,
          do_you_have_allergies: body.do_you_have_allergies
            ? body.do_you_have_allergies
            : [],
          dietary_preferences: body.dietary_preferences
            ? body.dietary_preferences
            : "",
          day_you_eat_out: body.day_you_eat_out ? body.day_you_eat_out : "",
          selected_cuisine: body.selected_cuisine ? body.selected_cuisine : "",
          favourite_places: body.favourite_places ? body.favourite_places : "",
          selected_chain: body.selected_chain ? body.selected_chain : "",
          push_notification: body.push_notification
            ? body.push_notification
            : "",
          sms_notification: body.sms_notification ? body.sms_notification : "",
          email_notification: body.email_notification
            ? body.email_notification
            : ""
        });
        let newyourSelf = await newYourself.save();
        next();
      }
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.check_unique_email = async (req, res, next) => {
  try {
    const body = req.body;
    let check_unique_email = await AmaelioUsers.findOne({
      email: body.email,
      mobile_number: body.mobile_number
    });
    if (check_unique_email) {
      return res.status(200).json({
        message: "Please Enter Mobile Number"
      });
    } else {
      next();
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.google_user_mobile_number_update = async (req, res, next) => {
  try {
    const body = req.body;
    let check_unique_mobile = await AmaelioUsers.findOne({
      mobile_number: body.mobile_number
    });
    if (check_unique_mobile) {
      return res.status(400).json({
        message: "User Already Exites"
      });
    }
    let data = await AmaelioUsers.findOneAndUpdate(
      {
        email: body.email
      },
      {
        $set: {
          mobile_number: body.mobile_number
        }
      }
    );
    if (data) {
      next();
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};
