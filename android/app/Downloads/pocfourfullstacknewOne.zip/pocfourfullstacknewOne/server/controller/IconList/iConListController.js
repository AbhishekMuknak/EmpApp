const IconList = require("../../models/IconList.model");

exports.get_all_icons = async (req, res, next) => {
  let allIcons = await IconList.find({ category: { $ne: "chain" } });
  return res.status(200).json(allIcons);
};

exports.create_new_chain = async (req, res, next) => {
  try {
    const body = req.body;
    const newIcon = new IconList({
      icon: body.icon,
      title: body.title,
      category: "chains"
    });
    let saveIcon = await newIcon.save();
    if (saveIcon) {
      return res
        .status(200)
        .json({ message: "New Chain Added Successfully!!" });
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.get_all_chains = async (req, res, next) => {
  try {
    let allChains = await IconList.find({ category: "chain" });
    return res.status(200).json(allChains);
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.create_new_icon = async (req, res, next) => {
  try {
    const body = req.body;
    const newIcon = new IconList({
      icon: body.icon,
      title: body.title,
      category: body.category
    });
    let saveIcon = await newIcon.save();
    if (saveIcon) {
      return res.status(200).json({ message: "New Icon Added Successfully!!" });
    }
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.get_chain = async (req, res, next) => {
  try {
    // const id = jwt.verify(req.headers.authorization.split(" ")[1], keys)._id;
    let data = await IconList.find({ category: "chains" });
    return res.status(200).json(data);
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.get_food_type = async (req, res, next) => {
  try {
    let data = await IconList.find({ category: "Food Type" });
    return res.status(200).json(data);
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};

exports.get_allergy_info = async (req, res, next) => {
  try {
    let data = await IconList.find({ category: "Allergy info" });
    return res.status(200).json(data);
  } catch (err) {
    let errors = {};
    console.log(err);
    errors.SERVER_ERRORS = "Internal Errors Please Try Again";
    return res.status(500).json(errors);
  }
};
