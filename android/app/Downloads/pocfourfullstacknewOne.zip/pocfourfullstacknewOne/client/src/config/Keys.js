export const serverName = "http://34.204.90.1:5001";

export const socketIpAddress = "https://vendordashboard.amealio.in";

//Local Server Proxy ==> http://localhost:5001/

//Main Server Proxy ==> https://vendordashboard.amealio.in/

//Socket Io Local Ip Address ==> http://localhost:5001/

//Socket Io Main Server Ip Address ==> https://vendordashboard.amealio.in
