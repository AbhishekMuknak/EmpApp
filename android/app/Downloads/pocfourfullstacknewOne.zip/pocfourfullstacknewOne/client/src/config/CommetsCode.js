// monday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       breakfast_opening_time: "",
//       breakfast_closing_time: ""
//     },
//     lunch: {
//       open: false,
//       lunch_opening_time: "",
//       lunch_closing_time: ""
//     },
//     dinner: {
//       open: false,
//       dinner_opening_time: "",
//       dinner_closing_time: ""
//     }
//   },
//   tuesday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       breakfast_opening_time: "",
//       breakfast_closing_time: ""
//     },
//     lunch: {
//       open: false,
//       lunch_opening_time: "",
//       lunch_closing_time: ""
//     },
//     dinner: {
//       open: false,
//       dinner_opening_time: "",
//       dinner_closing_time: ""
//     }
//   },
//   wednesday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       breakfast_opening_time: "",
//       breakfast_closing_time: ""
//     },
//     lunch: {
//       open: false,
//       lunch_opening_time: "",
//       lunch_closing_time: ""
//     },
//     dinner: {
//       open: false,
//       dinner_opening_time: "",
//       dinner_closing_time: ""
//     }
//   },
//   thursday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       breakfast_opening_time: "",
//       breakfast_closing_time: ""
//     },
//     lunch: {
//       open: false,
//       lunch_opening_time: "",
//       lunch_closing_time: ""
//     },
//     dinner: {
//       open: false,
//       dinner_opening_time: "",
//       dinner_closing_time: ""
//     }
//   },
//   friday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       breakfast_opening_time: "",
//       breakfast_closing_time: ""
//     },
//     lunch: {
//       open: false,
//       lunch_opening_time: "",
//       lunch_closing_time: ""
//     },
//     dinner: {
//       open: false,
//       dinner_opening_time: "",
//       dinner_closing_time: ""
//     }
//   },
//   saturday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       breakfast_opening_time: "",
//       breakfast_closing_time: ""
//     },
//     lunch: {
//       open: false,
//       lunch_opening_time: "",
//       lunch_closing_time: ""
//     },
//     dinner: {
//       open: false,
//       dinner_opening_time: "",
//       dinner_closing_time: ""
//     }
//   },
//   sunday: {
//     open: false,
//     main_opening_time: "",
//     main_closing_time: "",
//     breakfast: {
//       open: false,
//       opening_time: "",
//       closing_time: ""
//     },
//     lunch: {
//       open: false,
//       opening_time: "",
//       closing_time: ""
//     },
//     dinner: {
//       open: false,
//       opening_time: "",
//       closing_time: ""
//     }
//   },

// monday: {
//   open: nextProps.details.restauranttime_details.monday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.monday.main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.monday.main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.monday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.monday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.monday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.monday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.monday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.monday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open: nextProps.details.restauranttime_details.monday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.monday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.monday.dinner
//         .dinner_closing_time
//   }
// },
// tuesday: {
//   open: nextProps.details.restauranttime_details.tuesday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.tuesday.main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.tuesday.main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.tuesday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.tuesday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.tuesday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.tuesday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.tuesday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.tuesday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open: nextProps.details.restauranttime_details.tuesday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.tuesday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.tuesday.dinner
//         .dinner_closing_time
//   }
// },
// wednesday: {
//   open: nextProps.details.restauranttime_details.wednesday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.wednesday
//       .main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.wednesday
//       .main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.wednesday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.wednesday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.wednesday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.wednesday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.wednesday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.wednesday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open:
//       nextProps.details.restauranttime_details.wednesday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.wednesday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.wednesday.dinner
//         .dinner_closing_time
//   }
// },
// thursday: {
//   open: nextProps.details.restauranttime_details.thursday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.thursday.main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.thursday.main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.thursday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.thursday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.thursday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.thursday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.thursday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.thursday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open: nextProps.details.restauranttime_details.thursday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.thursday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.thursday.dinner
//         .dinner_closing_time
//   }
// },
// friday: {
//   open: nextProps.details.restauranttime_details.friday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.friday.main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.friday.main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.friday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.friday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.friday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.friday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.friday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.friday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open: nextProps.details.restauranttime_details.friday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.friday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.friday.dinner
//         .dinner_closing_time
//   }
// },
// saturday: {
//   open: nextProps.details.restauranttime_details.saturday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.saturday.main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.saturday.main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.saturday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.saturday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.saturday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.saturday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.saturday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.saturday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open: nextProps.details.restauranttime_details.saturday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.saturday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.saturday.dinner
//         .dinner_closing_time
//   }
// },
// sunday: {
//   open: nextProps.details.restauranttime_details.sunday.open,
//   main_opening_time:
//     nextProps.details.restauranttime_details.sunday.main_opening_time,
//   main_closing_time:
//     nextProps.details.restauranttime_details.sunday.main_closing_time,
//   breakfast: {
//     open:
//       nextProps.details.restauranttime_details.sunday.breakfast.open,
//     breakfast_opening_time:
//       nextProps.details.restauranttime_details.sunday.breakfast
//         .breakfast_opening_time,
//     breakfast_closing_time:
//       nextProps.details.restauranttime_details.sunday.breakfast
//         .breakfast_closing_time
//   },
//   lunch: {
//     open: nextProps.details.restauranttime_details.sunday.lunch.open,
//     lunch_opening_time:
//       nextProps.details.restauranttime_details.sunday.lunch
//         .lunch_opening_time,
//     lunch_closing_time:
//       nextProps.details.restauranttime_details.sunday.lunch
//         .lunch_closing_time
//   },
//   dinner: {
//     open: nextProps.details.restauranttime_details.sunday.dinner.open,
//     dinner_opening_time:
//       nextProps.details.restauranttime_details.sunday.dinner
//         .dinner_opening_time,
//     dinner_closing_time:
//       nextProps.details.restauranttime_details.sunday.dinner
//         .dinner_closing_time
//   }
// },

/**********************************
 * @DESC SOCKET IO SERVER COMMENT
 ***********************************/
// io.on("connection", socket => {
//   socket.on("subscribeData", data => {
//     Dinner.find({
//       vendor_id: data,
//       $or: [
//         {
//           dinner_status: "Nonseated"
//         },
//         {
//           dinner_status: "Seated"
//         }
//       ]
//     })
//       .exec()
//       .then(DinnerList => {
//         io.emit("getData", DinnerList);
//       });
//   });

//   socket.on("usersubscribeDataWaitlist", data => {
//     const id = jwt.verify(data.split(" ")[1], keys)._id;
//     Dinner.find({
//       user_id: id,
//       order_type: "waitlist"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetDataWaitlist", UserDinnerList);
//       });
//   });

//   socket.on("usersubscribeDatawalkin", data => {
//     const id = jwt.verify(data.split(" ")[1], keys)._id;
//     Dinner.find({
//       user_id: id,
//       order_type: "walkin"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetDataWalkin", UserDinnerList);
//       });
//   });

//   socket.on("usersubscribeDataReservation", data => {
//     const id = jwt.verify(data.split(" ")[1], keys)._id;
//     Dinner.find({
//       user_id: id,
//       order_type: "reservation"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetDataReservation", UserDinnerList);
//       });
//   });

//   socket.on("pendingData", data => {
//     Dinner.find({
//       vendor_id: data,
//       order_type: "reservation",
//       status: "Pending"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("userGetDataReservation", UserDinnerList);
//       });
//   });

//   socket.on("updateData", async data => {
//     let data1 = await Dinner.findByIdAndUpdate(
//       {
//         _id: data.dinnerId
//       },
//       {
//         $set: {
//           dinner_status: data.dinner_status,
//           Seating_Date: Date.now()
//         }
//       }
//     );
//     if (data1)
//       Dinner.find({
//         user_id: data1.user_id,
//         order_type: data1.order_type
//       })
//         .exec()
//         .then(UserDinnerList => {
//           io.emit("usergetDataWalkin", UserDinnerList);
//         });
//     Dinner.find({
//       user_id: data1.user_id,
//       order_type: data1.order_type
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetDataWaitlist", UserDinnerList);
//       });
//     Dinner.find({
//       user_id: data1.user_id,
//       order_type: data1.order_type
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetDataReservation", UserDinnerList);
//       });
//     client.messages
//       .create({
//         body: "Your Are Now" + data.dinner_status,
//         messagingServiceSid: "MG47e9a75679be5a94cf3c00e9fa1837dd",
//         form: "+14152003837",
//         to: data1.phone_number
//       })
//       .then(message => message.sid);
//     var messagepush = {
//       notification: {
//         title: "Amealio App",
//         body: data.dinner_status
//       },
//       token: data1.token
//     };
//     FCM.send(messagepush, (err, response) => {});
//   });

//   socket.on("reservationStatusUpdate", async data => {
//     if (data.status === "Accepted") {
//       let a = await Dinner.findByIdAndUpdate(
//         {
//           _id: data.id
//         },
//         {
//           $set: {
//             status: data.status,
//             ETA: data.ETA ? data.ETA : "",
//             reject_reasons: data.reject_reasons ? data.reject_reasons : "",
//             enter_reasons: data.enter_reasons ? data.enter_reasons : "",
//             Seating_Date: Date.now(),
//             dinner_status: "Nonseated"
//           }
//         }
//       );
//       if (a) {
//         Dinner.find({
//           user_id: data.user_id,
//           order_type: "reservation"
//         })
//           .exec()
//           .then(UserDinnerList => {
//             io.emit("usergetDataReservation", UserDinnerList);
//           });
//       }
//     } else if (data.status === "Cancelled") {
//       let b = await Dinner.findByIdAndUpdate(
//         {
//           _id: data.id
//         },
//         {
//           $set: {
//             status: data.status,
//             ETA: data.ETA ? data.ETA : "",
//             reject_reasons: data.reject_reasons ? data.reject_reasons : "",
//             enter_reasons: data.enter_reasons ? data.enter_reasons : "",
//             Seating_Date: Date.now(),
//             dinner_status: "Cancelled"
//           }
//         }
//       );
//       if (b) {
//         console.log("Hiii");
//         Dinner.find({
//           user_id: data.user_id,
//           order_type: "reservation"
//         })
//           .exec()
//           .then(UserDinnerList => {
//             io.emit("usergetDataReservation", UserDinnerList);
//           });
//       }
//     }
//   });

//   socket.on("updateWaitTimeData", async data => {
//     var newdate = moment(new Date(), "DD/MM/YYYY hh:mm:ss A")
//       .add(data.wait_time * 60, "seconds")
//       .format("DD/MM/YYYY hh:mm:ss A");
//     let updateDinnerWaitTime = await Dinner.findOneAndUpdate(
//       {
//         _id: data._id
//       },
//       {
//         $set: {
//           wait_time: newdate
//         }
//       }
//     );
//     if (updateDinnerWaitTime) {
//       Dinner.find({
//         user_id: updateDinnerWaitTime.user_id,
//         order_type: updateDinnerWaitTime.order_type
//       })
//         .exec()
//         .then(UserDinnerList => {
//           io.emit("usergetDataWalkin", UserDinnerList);
//         });
//       Dinner.find({
//         user_id: updateDinnerWaitTime.user_id,
//         order_type: updateDinnerWaitTime.order_type
//       })
//         .exec()
//         .then(UserDinnerList => {
//           io.emit("usergetDataWaitlist", UserDinnerList);
//         });
//       client.messages
//         .create({
//           body:
//             "Your New Waiting Time is Updated " + data.wait_time + "Minutes",
//           messagingServiceSid: "MG47e9a75679be5a94cf3c00e9fa1837dd",
//           form: "+14152003837",
//           to: updateDinnerWaitTime.phone_number
//         })
//         .then(message => res.json(message.sid));
//       var messagepush = {
//         notification: {
//           title: "Amealio App",
//           body: data.wait_time
//         },
//         token: updateDinnerWaitTime.token
//       };
//       FCM.send(messagepush, (err, response) => {});
//     }
//   });
// });

// io.on("connection", socket => {
//   socket.on("subscribeData", data => {
//     Dinner.find({
//       vendor_id: data,
//       $or: [{ dinner_status: "Nonseated" }, { dinner_status: "Seated" }]
//     })
//       .exec()
//       .then(DinnerList => {
//         io.emit("getData", DinnerList);
//       });
//   });

//   socket.on("usersubscribeData", data => {
//     const id = jwt.verify(data.split(" ")[1], keys)._id;
//     Dinner.find({
//       user_id: id,
//       order_type: "waitlist"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetData", UserDinnerList);
//       });
//   });

//   socket.on("usersubscribeDatawalkin", data => {
//     const id = jwt.verify(data.split(" ")[1], keys)._id;
//     Dinner.find({
//       user_id: id,
//       order_type: "walkin"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetDatawalkin", UserDinnerList);
//       });
//   });

//   socket.on("usersubscribeDatareservation", data => {
//     const id = jwt.verify(data.split(" ")[1], keys)._id;
//     Dinner.find({
//       user_id: id,
//       order_type: "reservation"
//     })
//       .exec()
//       .then(UserDinnerList => {
//         io.emit("usergetData", UserDinnerList);
//       });
//   });

//   socket.on("updateData", async data => {
//     //console.log(data);
//     let data1 = await Dinner.findByIdAndUpdate(
//       {
//         _id: data.dinnerId
//       },
//       {
//         $set: {
//           dinner_status: data.dinner_status,
//           Seating_Date: Date.now()
//         }
//       }
//     );

//     if (data1)
//       // client.messages.create({
//       //   body: "Your are now" + data.dinner_status,
//       //   messagingServiceSid: "MG47e9a75679be5a94cf3c00e9fa1837dd",
//       //   form: "+14152003837",
//       //   to: data1.phone_number
//       // });

//       Dinner.find({ user_id: data1.user_id })
//         .exec()
//         .then(UserDinnerList => {
//           io.emit("usergetData", UserDinnerList);
//         });
//   });

//   socket.on("updateWaitTimeData", async data => {
//     //console.log(data)
//     var newdate = moment(new Date(), "DD/MM/YYYY hh:mm:ss A")
//       .add(data.wait_time * 60, "seconds")
//       .format("DD/MM/YYYY hh:mm:ss A");
//     let updateDinnerWaitTime = await Dinner.findOneAndUpdate(
//       {
//         _id: data._id
//       },
//       {
//         $set: {
//           wait_time: newdate
//         }
//       }
//     );
//     if (updateDinnerWaitTime) {
//       Dinner.find({ user_id: updateDinnerWaitTime.user_id })
//         .exec()
//         .then(UserDinnerList => {
//           io.emit("usergetData", UserDinnerList);
//         });
//       Dinner.find({ vendor_id: data.vendor_id })
//         .exec()
//         .then(DinnerList => {
//           io.emit("getData", DinnerList);
//         });
//     }
//   });
// });

// message: `${
//     newMessage === "Nonseated" && orderType === "waitlist"
//       ? `You have been added to waitlist. Your wait time is ${this.state.defaultWaitTime} minutes.`
//       : null || (newMessage === "Nonseated" && orderType === "walkin")
//       ? `You have been added to walkin. Your wait time is 00 minutes`
//       : null || (newMessage === "Nonseated" && orderType === "reservation")
//       ? `You have been added to reservation. Your wait time is 00 minutes`
//       : null || (newMessage === "Seated" && orderType === "waitlist")
//       ? `Bon Appetit! You have now been seated.`
//       : null || (newMessage === "Seated" && orderType === "walkin")
//       ? `Bon Appetit! You have now been seated.`
//       : null || (newMessage === "Seated" && orderType === "reservation")
//       ? `Bon Appetit! You have now been seated.`
//       : null || (newMessage === "Completed" && orderType === "waitlist")
//       ? `You have been completed. We hope your have enjoyed our food. Visit us again`
//       : null || (newMessage === "Completed" && orderType === "walkin")
//       ? `You have been completed. We hope your have enjoyed our food. Visit us again`
//       : null || (newMessage === "Completed" && orderType === "reservation")
//       ? `You have been completed. We hope your have enjoyed our food. Visit us again`
//       : null || (newMessage === "Cancelled" && orderType === "waitlist")
//       ? `Oops, we're sorry! Your waitlist request is rejected. Request again for a waitlist in here.`
//       : null || (newMessage === "Cancelled" && orderType === "walkin")
//       ? `Oops, we're sorry! Your walk-in request is rejected. Request again for a walk-in here.`
//       : null ||
//         (newMessage === "Cancelled" && orderType === "reservation") ||
//         status === "Accepted"
//       ? `Oops, we're sorry! Your reservation request is rejected. Request again for a reservation in here.`
//       : null
//   }`
