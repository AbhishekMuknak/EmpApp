import React, { Component } from 'react';

export class VendorsPendingComponents extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>Pending</h1>
      </React.Fragment>
    );
  }
}

export default VendorsPendingComponents;
