import React, { Component } from 'react';

export class VendorReservationsComponents extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>Reservations</h1>
      </React.Fragment>
    );
  }
}

export default VendorReservationsComponents;
