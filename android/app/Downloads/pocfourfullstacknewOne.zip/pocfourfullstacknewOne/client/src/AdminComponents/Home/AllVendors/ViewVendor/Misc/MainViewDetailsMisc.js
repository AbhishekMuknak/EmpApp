import React, { Component } from 'react';

export class MainViewDetailsMisc extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>MISC Page</h1>
      </React.Fragment>
    );
  }
}

export default MainViewDetailsMisc;
