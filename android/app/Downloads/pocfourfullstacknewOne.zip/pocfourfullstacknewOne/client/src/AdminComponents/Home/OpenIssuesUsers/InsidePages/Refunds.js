import React from "react";

export const Refunds = () => {
  return (
    <React.Fragment>
      <div>Refunds Page</div>
    </React.Fragment>
  );
};

export default Refunds;
