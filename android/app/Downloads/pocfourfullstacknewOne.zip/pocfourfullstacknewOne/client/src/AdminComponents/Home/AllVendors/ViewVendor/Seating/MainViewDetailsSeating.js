import React, { Component } from 'react';
import InsideSubHeader from '../../InsideSubHeader';

export class MainViewDetailsSeating extends Component {
  render() {
    return (
      <React.Fragment>
        <InsideSubHeader />
      </React.Fragment>
    );
  }
}

export default MainViewDetailsSeating;
