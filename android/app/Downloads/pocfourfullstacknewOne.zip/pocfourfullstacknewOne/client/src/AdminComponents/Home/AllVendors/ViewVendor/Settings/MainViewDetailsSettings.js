import React, { Component } from 'react';

export class MainViewDetailsSettings extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>Settings Page</h1>
      </React.Fragment>
    );
  }
}

export default MainViewDetailsSettings;
