import React from "react";

const BodyTableUser = ({
  no,
  firstname,
  lastname,
  imgclass,
  email,
  phone,
  code,
  city,
  member,
  transactions,
  eyeonclick
}) => {
  return (
    <React.Fragment>
      <tr className="table-rowclass">
        <td>{no}</td>
        <td>
          {firstname} {lastname}
          <div className="mt-2">
            <img
              src={require("../../../../assets/images/AdminDashboard/home/phone.png")}
              alt="phone img"
              className="user-logo-img"
            />
            <img
              src={require("../../../../assets/images/AdminDashboard/home/message.png")}
              alt="message img"
              className="user-logo-img"
            />
            <img
              src={require("../../../../assets/images/AdminDashboard/home/notification.png")}
              alt="notification img"
              className="user-logo-img mr-0"
            />
          </div>
        </td>
        <td>{email}</td>
        <td>
          +{code} {phone}
        </td>
        <td>{city}</td>
        <td>{member}</td>
        <td>{transactions}</td>
        <td>
          <img
            src={require("../../../../assets/images/AdminDashboard/home/delete.png")}
            alt="delete img"
            className="user-logo-img"
          />
          <img
            src={require("../../../../assets/images/AdminDashboard/home/flag.png")}
            alt="flag img"
            className="user-logo-img"
          />
          <img
            src={require("../../../../assets/images/AdminDashboard/home/lock.png")}
            alt="lock img"
            className="user-logo-img"
          />
        </td>
        <td></td>
        <td>
          <img
            src={require("../../../../assets/images/AdminDashboard/home/eye.png")}
            alt="eye img"
            className="user-logo-img"
            onClick={eyeonclick}
          />
          <img
            src={require("../../../../assets/images/AdminDashboard/home/edit.png")}
            alt="edit img"
            className="user-logo-img"
          />
        </td>
      </tr>
    </React.Fragment>
  );
};

export default BodyTableUser;
