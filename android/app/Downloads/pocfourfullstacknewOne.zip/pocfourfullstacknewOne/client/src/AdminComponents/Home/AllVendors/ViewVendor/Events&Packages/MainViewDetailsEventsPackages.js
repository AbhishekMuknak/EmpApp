import React, { Component } from 'react';

export class MainViewDetailsEventsPackages extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>Event & Packages Page</h1>
      </React.Fragment>
    );
  }
}

export default MainViewDetailsEventsPackages;
