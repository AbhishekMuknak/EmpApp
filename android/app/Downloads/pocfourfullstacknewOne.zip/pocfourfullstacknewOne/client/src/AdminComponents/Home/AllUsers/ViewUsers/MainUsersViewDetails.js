import React, { Component } from 'react';
import AdminNavbar from '../../../AdminReusableComponent/NavBarComponent/AdminNavbar';

export class MainUsersViewDetails extends Component {
  render() {
    return (
      <React.Fragment>
        <AdminNavbar />
      </React.Fragment>
    );
  }
}

export default MainUsersViewDetails;
