import React, { Component } from 'react';

export class VendorHistoryComponents extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>History</h1>
      </React.Fragment>
    );
  }
}

export default VendorHistoryComponents;
