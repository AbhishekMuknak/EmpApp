import React, { Component } from 'react';

export class MainViewDetailsOrdering extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>Ordering Page</h1>
      </React.Fragment>
    );
  }
}

export default MainViewDetailsOrdering;
