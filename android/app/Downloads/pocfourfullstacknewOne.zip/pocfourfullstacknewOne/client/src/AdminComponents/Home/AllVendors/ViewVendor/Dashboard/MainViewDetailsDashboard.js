import React, { Component } from 'react';

export class MainViewDetailsDashboard extends Component {
  render() {
    return (
      <React.Fragment>
        <div className='col-12'>
          <h1>Dashboard</h1>
        </div>
      </React.Fragment>
    );
  }
}

export default MainViewDetailsDashboard;
