import React, { Component } from "react";
import Login from "../Login/Login";

export class VendorLogin extends Component {
  render() {
    return (
      <React.Fragment>
        <Login />
      </React.Fragment>
    );
  }
}

export default VendorLogin;
