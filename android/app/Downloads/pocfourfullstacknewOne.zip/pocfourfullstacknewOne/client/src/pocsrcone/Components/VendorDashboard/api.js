// import openSocket from "socket.io-client";

// const socket = openSocket("http://localhost:4000");
// function subscribeData(cb) {
//   socket.on("getData", data => {
//     console.log("getData", data);
//     cb(null, data);
//   });

//   socket.emit("subscribeData", 10000);
// }
// export { subscribeData };

// debugger;
// const socket = socketIOClient("http://localhost:4002/dinner", {
//   headers: { "Access-Control-Allow-Origin": "*" }
// });
// socket.on("connection", data => {
//   console.log("mysocketdata", data);
// });
// socket.emit("connection", "1");
// // socket.emit("subscribeData", nextprops.dinner);
// // socket.on("getData", data => {
// //   console.log("getData", data);
// //   return { dinnerList: data };
// // });
// return nextprops.dinner;

/// ******************* add dinner file code to ************** //////
// const app = express();
// var mongoose = require("mongoose");
// var mongoURI = `mongodb+srv://rest-api:rest-api@cluster0-uouvd.mongodb.net/pocfour?retryWrites=true&w=majority`;

// var http = require("http").Server(router);
// var io = require("socket.io")(http);
// const httpp = require("http");
// const port = "4002";
// const server = httpp.createServer(app);
// const cors = require("cors");

// app.use(cors());

// var Message = mongoose.model("Dinner", {
//   name: {
//     type: String
//     //require: true
//   },
//   phone_number: {
//     type: String
//     //require: true
//   },
//   adults: {
//     type: String
//     //require: true
//   },
//   kids: {
//     type: String
//     //require: true
//   },
//   highchair: {
//     type: Number
//   },
//   handicap: {
//     type: Number
//   },
//   Date: {
//     type: String
//   },
//   time: {
//     type: String
//   },
//   seating_preference: {
//     type: Array
//   },
//   reasons_for_Cancel: {
//     type: Array
//   },
//   Enter_reasons: {
//     type: String
//   },
//   special_occassion: {
//     type: String
//   },
//   dinner_status: {
//     type: String
//   },
//   reservation_status: {
//     type: String
//   },
//   total: {
//     type: Number
//     //require: true
//   },
//   vendor_id: {
//     type: String
//     //require: true
//   },
//   wait_time: {
//     type: Number
//     //require: true
//   },
//   status: {
//     type: String
//     // require: true
//   },
//   ETA: {
//     type: String
//   },
//   Request_Date: {
//     type: Date
//   },
//   Seating_Date: {
//     type: Date
//   },
//   reject_reasons: {
//     type: String
//   },
//   enter_reasons: {
//     type: String
//   },
//   entry_point: {
//     type: String
//   },
//   user_id: {
//     type: String
//   },
//   restaurant_name: {
//     type: String
//   },
//   booking_date: {
//     type: Date
//   },
//   order_type: {
//     type: String
//   },
//   time: {
//     type: String
//   },
//   register_date: {
//     type: Date
//   },
//   token: {
//     type: String
//   }
// });

// router.get("/dinner", (req, res) => {
//   Message.find({}, (err, messages) => {
//     res.send(messages);
//   });
// });

// io.on("connection", socket => {
//   console.log("a user has been connected", socket);
//   // socket.on("incoming data", data => {
//   //   //Here we broadcast it out to all other sockets EXCLUDING the socket which sent us the data
//   //   socket.broadcast.emit("outgoing data", { num: data });
//   // });

//   // //A special namespace "disconnect" for when a client disconnects
//   // socket.on("disconnect", () => console.log("Client disconnected"));
// });
// io.emit("connection", "1");

// mongoose
//   .connect(mongoURI, {
//     useNewUrlParser: true,
//     useCreateIndex: true,
//     useFindAndModify: false
//   })
//   .then(() => console.log("socketDatabase Connected Successfully!!!"))
//   .catch(err => console.log("Error while connecting to the database" + err));

// server.listen(port, () => console.log(`Listening on port ${port}`));

/***************************
 @desc Server.js
******************************/
// const io = require("socket.io")();

// io.on("connection", socket => {
//   console.log("Connection Established");
//   socket.on("subscribeData", interval => {
//     console.log("client is subscribing data with interval ", interval);
//     // setInterval(() => {

//     // }, interval);
//     socket.emit(
//       "getData",
//       {dinnerData: interval}
//     );
//   });
// });
