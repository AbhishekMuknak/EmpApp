import React, { Component } from "react";

export class MainOrderingReport extends Component {
  render() {
    return (
      <React.Fragment>
        <h1> hhiii Ordering report</h1>
      </React.Fragment>
    );
  }
}

export default MainOrderingReport;
