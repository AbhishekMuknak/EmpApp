import React, { Component } from "react";
// import IconBoxButtonComponent from '../../reusableComponents/IconBoxButtonComponent';
import NavbarDashboard from "./NavbarDashboard";
// import SuggestNew from '../../reusableComponents/SuggestNew';

export class MainDashboard extends Component {
  render() {
    return (
      <React.Fragment>
        <div className="container-fluid">
          <div className="row">
            <NavbarDashboard />
          </div>
          <div className="row">
            {/* <IconBoxButtonComponent
              title='indor'
              classsection='main-icon-button active'
              src={require('../../assets/images/button-icons/burger.png')}
            />
            <SuggestNew
              title='Suggest New'
              classsection='main-suggest-button'
            /> */}
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default MainDashboard;
//02/06/2020
