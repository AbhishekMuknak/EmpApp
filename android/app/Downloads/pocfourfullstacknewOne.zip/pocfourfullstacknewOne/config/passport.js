const JWTStrategy = require('passport-jwt').Strategy;
const ExtractJWT = require('passport-jwt').ExtractJwt;
const User = require('../server/models/User.model');
const keys = require('./keys');

const opts = {};
opts.jwtFromRequest = ExtractJWT.fromAuthHeaderAsBearerToken();
opts.secretOrKey = keys.secretIOkey;

module.exports = passport => {
    passport.use(
        new JWTStrategy(opts, (jwt_payload,done) => {
            User.findById(jwt_payload._id)
                .then(user => {
                    if(user){
                        return done( null, user )
                    }
                    return done( null,false );
                })
                .catch(err => {
                  //  console.log(err);
                })
        }));
};