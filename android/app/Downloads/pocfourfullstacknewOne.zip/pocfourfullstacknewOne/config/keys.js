module.exports = {
  mongoURI: `mongodb+srv://rest-api:rest-api@cluster0-uouvd.mongodb.net/pocfour?retryWrites=true&w=majority`,
  //mongoURI: `mongodb+srv://rest-api:rest-api@cluster0-uouvd.mongodb.net/pocfour_test?retryWrites=true&w=majority`,
  secretIOkey: "secretkeypocfour1234567@#@##@"
};
